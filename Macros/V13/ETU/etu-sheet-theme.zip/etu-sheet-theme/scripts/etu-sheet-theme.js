/**
 * ETU Sheet Theme — applique une classe CSS "etu-sheet-theme" sur les fiches
 * de personnage SWADE, sans toucher aux données ni à la logique du système.
 *
 * On s'accroche à la fois à "renderActorSheet" (ancienne API V1) et
 * "renderActorSheetV2" (nouvelle API ApplicationV2), Foundry ne déclenchant
 * que celui qui correspond réellement à la classe utilisée par le système.
 */

function appliquerTheme(app, html) {
  const actor = app.actor ?? app.document;
  if (!actor || actor.type !== "character") return;

  // html est un objet jQuery en V1, un HTMLElement direct en V2
  const racine = html instanceof HTMLElement ? html : html?.[0];
  if (!racine) return;

  racine.classList.add("etu-sheet-theme");
}

Hooks.on("renderActorSheet", appliquerTheme);
Hooks.on("renderActorSheetV2", appliquerTheme);
